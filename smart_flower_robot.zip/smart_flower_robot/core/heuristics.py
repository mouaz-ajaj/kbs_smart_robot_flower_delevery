"""
core/heuristics.py
==================
Heuristic functions for A* search.

The heuristic h(n) must be **admissible** (never over-estimates the true
remaining cost) so that A* is guaranteed to find the optimal solution.

Components of the heuristic
----------------------------
1. Operations cost: 1 for each required load + 1 for each required unload.
2. Distance cost: lower bound on the Manhattan distance needed to complete
   all remaining deliveries, including return trips to the warehouse.
"""

from __future__ import annotations

import math
from typing import Dict, Tuple

from core.models import Position, Problem


# ===========================================================================
#  Manhattan distance
# ===========================================================================

def manhattan_distance(a: Position, b: Position) -> int:
    """Return the Manhattan (L1) distance between two positions."""
    return abs(a.x - b.x) + abs(a.y - b.y)


# ===========================================================================
#  Heuristic
# ===========================================================================

def heuristic(
    robot_pos: Position,
    load: Dict[Tuple[str, str], int],
    remaining_needs: Dict[Tuple[str, str], int],
    problem: Problem,
) -> float:
    total_remaining = sum(v for v in remaining_needs.values() if v > 0)
    current_load = sum(load.values())

    if total_remaining == 0 and current_load == 0:
        return 0.0

    h = 0.0

    # -- Identify pavilions with outstanding needs
    pavilions_with_needs = set()
    for (pid, _color), qty in remaining_needs.items():
        if qty > 0:
            pavilions_with_needs.add(pid)

    # -- Operations Cost
    num_unloads = len(pavilions_with_needs)
    remaining_to_load_from_wh = max(0, total_remaining - current_load)
    num_loads = math.ceil(remaining_to_load_from_wh / problem.max_load)
    
    h += num_unloads + num_loads

    # -- Distance Cost
    if not pavilions_with_needs:
        return h

    min_w_to_p = min(
        manhattan_distance(problem.warehouse, pav.position)
        for pav in problem.pavilions if pav.id in pavilions_with_needs
    )

    if current_load == 0:
        # Robot is empty: must go to warehouse, then make `num_loads` forward trips
        # and `num_loads - 1` return trips.
        dist_to_w = manhattan_distance(robot_pos, problem.warehouse)
        forward_dist = num_loads * min_w_to_p
        return_dist = max(0, num_loads - 1) * min_w_to_p
        h += dist_to_w + forward_dist + return_dist

    else:
        # Robot has load: must deliver it to a useful pavilion.
        # Then it must make `num_loads` return trips to warehouse,
        # and `num_loads` forward trips to pavilions.
        min_deliver_dist = float("inf")
        for pav in problem.pavilions:
            if pav.id not in pavilions_with_needs:
                continue
            # Check if current load has anything useful for this pavilion
            useful = False
            for (ft, color), qty in load.items():
                if ft == pav.type:
                    rem = remaining_needs.get((pav.id, color), 0)
                    if rem > 0 and qty >= rem:
                        useful = True
                        break
            if useful:
                d = manhattan_distance(robot_pos, pav.position)
                if d < min_deliver_dist:
                    min_deliver_dist = d

        if min_deliver_dist == float("inf"):
            # Load is not useful right now, just go to nearest needy pavilion anyway
            # to be safe (or to warehouse, but going to pav is a safe lower bound for delivery)
            min_deliver_dist = min(
                manhattan_distance(robot_pos, pav.position)
                for pav in problem.pavilions if pav.id in pavilions_with_needs
            )

        forward_dist = num_loads * min_w_to_p
        return_dist = num_loads * min_w_to_p
        h += min_deliver_dist + forward_dist + return_dist

    return h
